package com.example.maap;

public class Order {

    private String name, order;

    public Order() {
    }

    public Order(String name, String order) {
        this.name = name;
        this.order = order;
    }
}
