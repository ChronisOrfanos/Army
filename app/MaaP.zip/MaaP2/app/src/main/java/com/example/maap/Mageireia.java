package com.example.maap;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Mageireia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mageireia);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getInstance().format(calendar.getWeekYear());
        //String dateFormat = DateFormat.getInstance().format(calendar);



        TextView textViewDate =  findViewById(R.id.date);
        textViewDate.setText(currentDate);
    }
}