package com.example.maap;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btn_mageireia, btn_kylikeio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_mageireia = findViewById(R.id.button_mageireia);
        btn_kylikeio = findViewById(R.id.button_kylikeio);

        btn_mageireia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMageireia_Activity();

            }
        });

        btn_kylikeio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openKylikeio_Activity();

            }
        });



    }

    private void openKylikeio_Activity() {
        Intent intent_kylikeio = new Intent(this, Kylikeio.class);
        startActivity(intent_kylikeio);
    }

    private void openMageireia_Activity() {
        Intent intent_mageireia = new Intent(this, Mageireia.class);
        startActivity(intent_mageireia);
    }
}